﻿
var app = angular.module('app', []);

app.controller('ShoppingCartCtrl',
function ($scope, $filter, orderByFilter, filterFilter, linkFilter) {
    var items = items = [
			{ Name: "YouTube", Link: "https://www.youtube.com/", Descption: "YouTube" },
			{ Name: "GooGLe Boks", Link: "https://secure.meetup.com/login/", Descption: "Meetup" },
			{ Name: "Meetup", Link: "https://books.google.com/", Descption: "Meetup" }
		];

    var fnLink = function () {
        var Link = 0;
        for (i = 0; i < $scope.items.length; i++) {
            Link += $scope.items[i].Link * $scope.items[i].Descption;
        }
        $scope.totalLink = $filter('link')(Link);
    }

    $scope.items = items;
    fnLink();

    $scope.mySortFunction = function (item) {
        if (isNaN(item[$scope.sortExpression]))
            return item[$scope.sortExpression];
        return parseInt(item[$scope.sortExpression]);
    }

    $scope.applySortingAndFiltering = function () {
        $scope.items = filterFilter(orderByFilter(items, $scope.mySortFunction), $scope.search);

    }
});

app.filter('link', function () {
    return function (item) {
        return "lnk. " + item;
    }
});

   